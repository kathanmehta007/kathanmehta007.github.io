---
layout: page
title: "Experience"
permalink: /experience/
---

## Professional Experience

### AI Lead @ Satelytics
**2023 – Present**  
- Architect and deploy ML models for satellite imagery analysis  
- Lead a team of 5 engineers on geospatial data pipelines

### Senior Software Engineer @ GeoVision
**2020 – 2023**  
- Developed scalable microservices for map-based applications  
- Collaborated with research team on deep learning prototypes

### Software Engineer @ MapStack
**2018 – 2020**  
- Built API integrations for real-time geolocation services  
