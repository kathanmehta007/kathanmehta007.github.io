---
layout: page
title: "About"
permalink: /about/
---

## Hi, I’m Kathan

I’m an AI Lead at Satelytics, working at the intersection of machine learning and geospatial analytics. I hold an M.S. in Electrical and Computer Engineering from Carnegie Mellon University.

### What I Do

- **AI & ML**: Building models to detect patterns in satellite imagery  
- **Geospatial Workflows**: Automating large-scale data pipelines  
- **Hobbies**: Hiking 🥾 · Photography 📸 · Cooking paneer tikka 🍽️
