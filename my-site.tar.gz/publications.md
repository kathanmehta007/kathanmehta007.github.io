---
layout: page
title: "Publications"
permalink: /publications/
---

## Journal & Conference Papers

1. **Mehta, K.**; Smith, J. “Deep Learning for Flood Detection” – *Remote Sensing*, 2024  
2. **Mehta, K.**; Lee, A. “Urban Change Analysis via Sentinel-2” – *IGARSS*, 2023  
