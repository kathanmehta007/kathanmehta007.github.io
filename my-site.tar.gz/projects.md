---
layout: page
title: "Projects"
permalink: /projects/
---

## Selected Projects

### Pan-Tikka Classifier
A CNN that detects paneer tikka from food photos with 92% accuracy.

### Flood-Detection Pipeline
Automated end-to-end workflow using Sentinel-2 imagery to flag flood events.

### Urban Change Detector
Time-series analysis of satellite imagery to monitor urban sprawl.
