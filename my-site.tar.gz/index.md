---
layout: home
title: "Welcome"
---

Welcome to my site! I'm **Kathan Nilesh Mehta**—AI Lead @ Satelytics with an M.S. in ECE from CMU.  
I build AI-powered geospatial workflows and love hiking, photography, and cooking paneer tikka.

<!--
Minimal Mistakes “home” layout will show:
  • A hero banner using `title` above
  • Featured posts (if you add any under _posts/)
  • Latest posts
  • Sidebar with about/info.
Feel free to customize by adding front matter options:
  https://mmistakes.github.io/minimal-mistakes/docs/home-pages/
-->
